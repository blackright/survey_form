-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 13, 2018 at 04:32 PM
-- Server version: 5.6.17-log
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `agric_net`
--

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `contact_person_name` varchar(100) NOT NULL,
  `phone_no` varchar(25) NOT NULL,
  `web_address` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `physical_address` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE IF NOT EXISTS `contacts` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `group` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `phone`, `location`, `group`) VALUES
(1, 'mahad kateregga', '0703898102', 'masaka', 'Coffee_Farmers_jja'),
(13, 'Joseph Musoke', '0702315454', 'iganga', 'Maize_Farmers_Iganga');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `client_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` bigint(20) NOT NULL,
  `message` text NOT NULL,
  `client_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` int(1) NOT NULL DEFAULT '0',
  `deleted_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `receipients`
--

CREATE TABLE IF NOT EXISTS `receipients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `location` varchar(100) NOT NULL,
  `client_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sms`
--

CREATE TABLE IF NOT EXISTS `tbl_sms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(100) NOT NULL,
  `sender` varchar(50) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `message` varchar(180) NOT NULL,
  `code` varchar(100) NOT NULL,
  `error_message` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=59 ;

--
-- Dumping data for table `tbl_sms`
--

INSERT INTO `tbl_sms` (`id`, `created_date`, `user_id`, `sender`, `contact`, `message`, `code`, `error_message`, `status`) VALUES
(1, '2018-03-20 15:10:12', 1, 'FARMUNION', 'Farmers_Jinja_D', 'Dear Members there will be a training on fertilizer usage this Monday 12 March 2018. Please attend in person', '1024', ' Messages Sent to Queue', 1),
(2, '2018-03-20 15:23:17', 1, 'AGRICUnion', 'Farmers_Entebbe', 'Dear Members there will be a training on fertilizer usage this Monday 12 March 2018. Please attend in persono', '1024', ' Messages Sent to Queue', 1),
(3, '2018-03-20 16:48:46', 1, 'AGRICUnion', 'All_Coffee_Farm', 'Dear Members the Rainy season starts soon. Now would be a perfect time to prepare your gardens', '1024', ' Messages Sent to Queue', 1),
(4, '2018-03-20 17:11:10', 2, 'Rea Consortium', 'Farmer_Coffee_M', 'Hello Paul, a buyer for your produce in egusi market is available. Please come with produce to our farm house to meet the buyer', '1024', ' Messages Sent to Queue', 0),
(5, '2018-03-20 17:46:41', 2, 'FARMUNION', 'Farmers_Entebbe', 'The Dry Season starts in the Month of September. I t will be the perfect time to dry your coffee and prepare it for sale at our farm house', '1024', ' Messages Sent to Queue', 1),
(6, '2018-03-20 17:47:26', 2, 'FARMUNION', 'All_Coffee_Farm', 'Hello Mary, a buyer for your produce in Owino market is available. Please come with produce to our farm house to meet the buyer', '1024', ' Messages Sent to Queue', 1),
(7, '2018-03-20 18:49:00', 2, 'FARMUNION', '2567895337890', 'Dear Andrew your produce is due for sale please collect fund', '1024', ' Messages Sent to Queue', 1),
(8, '2018-03-20 18:49:00', 2, 'EROGROUP', '256789045672', 'Dear Hagar your produce is due for sale please collect fund', '1024', ' Messages Sent to Queue', 1),
(9, '2018-03-20 19:09:44', 2, 'BULKSMS', '256785678903', 'The Dry Season starts in the Month of September. I t will be the perfect time to dry your coffee and prepare it for sale at our farm house', '1024', ' Messages Sent to Queue', 1),
(10, '2018-03-20 19:09:44', 2, 'BULKSMS', '256756786754', 'Pesticide for the Maize Weevil is available at our farm shop at only 20000 Ugx. Come get pesticide that will improve your yield', '1024', ' Messages Sent to Queue', 1),
(11, '2018-03-20 19:12:10', 2, 'AGRICSMS', '256774342182', 'Dear Members the Rainy season starts soon. Now would be a perfect time to prepare your gardens', '1024', ' Messages Sent to Queue', 1),
(12, '2018-03-20 19:12:10', 1, 'AGRICSMS', '256734567856', 'The Dry Season starts in the Month of September. I t will be the perfect time to dry your coffee and prepare it for sale at our farm house', '1024', ' Messages Sent to Queue', 1),
(13, '2018-03-20 19:13:37', 1, 'AGRICSMS', '256774342182', 'Pesticide for the Maize Weevil is available at our farm shop at only 20000 Ugx. Come get pesticide that will improve your yield', '1024', ' Messages Sent to Queue', 1),
(14, '2018-03-20 19:30:04', 1, 'EROGROUP', '256714326648', 'Omulimi waffe, tukwaniliza ku lukIiko lwaffe olwabalimu mu gombolola Kapeeka.', '1024', ' Messages Sent to Queue', 1),
(15, '2018-03-20 19:32:49', 1, 'BULKSMS', '256774342182', 'The Dry Season starts in the Month of September. I t will be the perfect time to dry your coffee and prepare it for sale at our farm house', '1024', ' Messages Sent to Queue', 1),
(16, '2018-03-21 01:49:00', 1, 'FARMUNION', '2567895337890', 'Dear Andrew your produce is due for sale please collect fund', '1024', ' Messages Sent to Queue', 1),
(17, '2018-03-21 01:49:00', 1, 'EROGROUP', '256789045672', 'Dear Hagar your produce is due for sale please collect fund', '1024', ' Messages Sent to Queue', 1),
(18, '2018-03-21 02:09:44', 1, 'BULKSMS', '256785678903', 'The Dry Season starts in the Month of September. I t will be the perfect time to dry your coffee and prepare it for sale at our farm house', '1024', ' Messages Sent to Queue', 1),
(19, '2018-03-21 02:09:44', 1, 'BULKSMS', '256756786754', 'Pesticide for the Maize Weevil is available at our farm shop at only 20000 Ugx. Come get pesticide that will improve your yield', '1024', ' Messages Sent to Queue', 1),
(20, '0000-00-00 00:00:00', 1, 'FARMUNION', '256774342182', 'Dear Members there will be a training on fertilizer usage this Monday 12 March 2018. Please attend in person', '1024', ' Messages Sent to Queue', 1),
(21, '2018-03-20 22:23:17', 1, 'AGRICSMS', '256752348176', 'Dear Members there will be a training on fertilizer usage this Monday 12 March 2018. Please attend in persono', '1024', ' Messages Sent to Queue', 1),
(22, '2018-03-20 23:48:46', 1, 'AGRICSMS', '256774456728', 'Dear Members the Rainy season starts soon. Now would be a perfect time to prepare your gardens', '1024', ' Messages Sent to Queue', 1),
(23, '2018-03-21 00:11:10', 1, 'BULKSMS', '256774342182', 'Hello Paul, a buyer for your produce in egusi market is available. Please come with produce to our farm house to meet the buyer', '1024', ' Messages Sent to Queue', 1),
(24, '2018-03-21 00:46:41', 1, 'FARMUNION', 'Farmer_Coffee_M', 'The Dry Season starts in the Month of September. I t will be the perfect time to dry your coffee and prepare it for sale at our farm house', '1024', ' Messages Sent to Queue', 1),
(25, '2018-03-21 00:47:26', 1, 'FARMUNION', 'Farmer_Group_X', 'Hello Mary, a buyer for your produce in Owino market is available. Please come with produce to our farm house to meet the buyer', '1024', ' Messages Sent to Queue', 1),
(26, '2018-03-21 01:49:00', 1, 'FARMUNION', '2567895337890', 'Dear Andrew your produce is due for sale please collect fund', '1024', ' Messages Sent to Queue', 1),
(27, '2018-03-21 01:49:00', 1, 'EROGROUP', '256789045672', 'Dear Hagar your produce is due for sale please collect fund', '1024', ' Messages Sent to Queue', 1),
(28, '2018-03-21 02:09:44', 1, 'BULKSMS', '256785678903', 'The Dry Season starts in the Month of September. I t will be the perfect time to dry your coffee and prepare it for sale at our farm house', '1024', ' Messages Sent to Queue', 1),
(29, '2018-03-21 02:09:44', 1, 'BULKSMS', '256756786754', 'Pesticide for the Maize Weevil is available at our farm shop at only 20000 Ugx. Come get pesticide that will improve your yield', '1024', ' Messages Sent to Queue', 1),
(30, '2018-03-21 02:12:10', 1, 'AGRICSMS', '256774342182', 'Dear Members the Rainy season starts soon. Now would be a perfect time to prepare your gardens', '1024', ' Messages Sent to Queue', 1),
(31, '2018-03-21 02:12:10', 1, 'AGRICSMS', '256734567856', 'The Dry Season starts in the Month of September. I t will be the perfect time to dry your coffee and prepare it for sale at our farm house', '1024', ' Messages Sent to Queue', 1),
(32, '2018-03-20 23:48:46', 1, 'AGRICSMS', '256774456728', 'Dear Members the Rainy season starts soon. Now would be a perfect time to prepare your gardens', '1024', ' Messages Sent to Queue', 1),
(33, '2018-03-21 00:11:10', 1, 'BULKSMS', '256774342182', 'Hello Paul, a buyer for your produce in egusi market is available. Please come with produce to our farm house to meet the buyer', '1024', ' Messages Sent to Queue', 1),
(34, '2018-03-21 00:46:41', 1, 'FARMUNION', 'Maize_Farmers', 'The Dry Season starts in the Month of September. I t will be the perfect time to dry your coffee and prepare it for sale at our farm house', '1024', ' Messages Sent to Queue', 1),
(35, '2018-03-21 02:13:37', 1, 'AGRICSMS', '256774342182', 'Pesticide for the Maize Weevil is available at our farm shop at only 20000 Ugx. Come get pesticide that will improve your yield', '1024', ' Messages Sent to Queue', 1),
(36, '2018-03-21 02:30:04', 1, 'EROGROUP', '256714326648', 'Omulimi waffe, tukwaniliza ku lukIiko lwaffe olwabalimu mu gombolola Kapeeka.', '1024', ' Messages Sent to Queue', 1),
(37, '2018-03-21 02:32:49', 1, 'BULKSMS', '256774342182', 'The Dry Season starts in the Month of September. I t will be the perfect time to dry your coffee and prepare it for sale at our farm house', '1024', ' Messages Sent to Queue', 1),
(38, '2018-03-21 07:50:17', 1, 'mahad', '256703898102', 'the season is so dry', '1024', ' Messages Sent to Queue', 1),
(39, '2018-03-21 08:40:28', 1, 'Mercrycops', 'Maize_farmers_j', 'dfasdfsdfafdsdf', '', '', 0),
(40, '2018-03-21 08:41:16', 1, 'Merycops', '256703898102', 'This season is predicted to be dry, please action accordingly', '1024', ' Messages Sent to Queue', 1),
(42, '2018-04-10 18:35:59', 1, 'sessions', '256703898102', 'sessions are active.', '', '', 0),
(43, '2018-04-10 18:36:06', 1, 'sessions', '256703898102', 'sessions are active.', '', '', 0),
(44, '2018-04-10 18:36:06', 1, 'sessions', '256703898102', 'sessions are active.', '', '', 0),
(45, '2018-04-10 18:36:06', 1, 'sessions', '256703898102', 'sessions are active.', '', '', 0),
(46, '2018-04-10 18:36:06', 1, 'sessions', '256703898102', 'sessions are active.', '', '', 0),
(47, '2018-04-10 18:36:06', 1, 'sessions', '256703898102', 'sessions are active.', '', '', 0),
(48, '2018-04-10 18:36:07', 1, 'sessions', '256703898102', 'sessions are active.', '', '', 0),
(49, '2018-04-10 18:36:07', 1, 'sessions', '256703898102', 'sessions are active.', '', '', 0),
(50, '2018-04-10 18:36:07', 1, 'sessions', '256703898102', 'sessions are active.', '', '', 0),
(51, '2018-04-10 18:36:07', 1, 'sessions', '256703898102', 'sessions are active.', '', '', 0),
(52, '2018-04-10 18:36:07', 1, 'sessions', '256703898102', 'sessions are active.', '', '', 0),
(53, '2018-04-10 18:37:16', 1, 'session', '256703898102', 'Sessions for planting have started', '', '', 0),
(54, '2018-04-10 18:39:57', 1, 'Mr. fred', '256703898102', 'Testing sessions', '', '', 0),
(55, '2018-04-10 18:43:22', 1, 'fred tests', '256703898102', 'testing sessions', '', '', 0),
(56, '2018-04-10 18:45:18', 2, 'fred testing', '256703898102', 'sessions tests 6.45', '', '', 0),
(57, '2018-04-10 18:46:05', 1, 'testing 6.50', '256703898102', 'sessions 6.50', '', '', 0),
(58, '2018-04-10 18:49:32', 3, 'kambuzi farmers', '256703898102', 'sessions 7.00pm', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_survey`
--

CREATE TABLE IF NOT EXISTS `tbl_survey` (
  `survey_id` int(11) NOT NULL AUTO_INCREMENT,
  `s_title` longtext NOT NULL,
  `s_question` longtext NOT NULL,
  `s_answer_one` varchar(50) NOT NULL,
  `s_answer_two` varchar(50) NOT NULL,
  `s_answer_three` varchar(50) NOT NULL,
  `grp_id` int(11) NOT NULL,
  `numbers` longtext NOT NULL,
  PRIMARY KEY (`survey_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_survey`
--

INSERT INTO `tbl_survey` (`survey_id`, `s_title`, `s_question`, `s_answer_one`, `s_answer_two`, `s_answer_three`, `grp_id`, `numbers`) VALUES
(1, 'The Impact of EHRM of Employee Peformance', 'Employees participating in online courses have an impact on organization Performance ', 'Agree', 'Desagree', 'i do not Know', 2, '256750689009');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE IF NOT EXISTS `tbl_users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobile_no` varchar(15) NOT NULL,
  `address` text NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`user_id`, `name`, `username`, `email`, `password`, `mobile_no`, `address`) VALUES
(1, 'Mahad Izzle', 'mahad', 'mahadizle@gmail.com', 'f1f501c2c23fea8dfb0fe1af25b879d1', '256703898102', 'Kampala'),
(2, 'Ndugwa Thomas', 'ndugwa2u2', 'ndugwa2u@yahoo.com', 'd6e1c05c8a81c2ae74c7aedea5ec92c1', '256774342182', 'Kampala'),
(3, 'kambuzi', 'kambuzi@gmail.com', 'kambuzi@gmail.com', 'kambuzi123', '', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

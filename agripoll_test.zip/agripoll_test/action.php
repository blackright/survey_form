<?php
require 'config.php';

$tsurvey = htmlspecialchars($_GET['tsurvey']);
$quest = htmlspecialchars($_GET['quest']);
$answer_one = htmlspecialchars($_GET['answer_one']);
$answer_two = htmlspecialchars($_GET['answer_two']);
$answer_three = htmlspecialchars($_GET['answer_three']);
$grp = htmlspecialchars($_GET['grp']);
$number = htmlspecialchars($_GET['number']);

$sql = "INSERT INTO tbl_survey (s_title, s_question, s_answer_one, s_answer_two, s_answer_three, grp_id, numbers) VALUES ('$tsurvey', '$quest', '$answer_one', '$answer_two', '$answer_three', '$grp', '$number')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close(); 


?>